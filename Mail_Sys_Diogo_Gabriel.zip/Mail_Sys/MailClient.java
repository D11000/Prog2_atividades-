import java.util.Scanner;

/**
 * Cliente simples de e-mail.
 */
public class MailClient {
    private MailBox mailbox;
    private Scanner in;

    public MailClient() {
        mailbox = new MailBox();
        in = new Scanner(System.in);
    }

    public void run() {
        boolean running = true;
        while (running) {
            System.out.println("1 - Enviar e-mail");
            System.out.println("2 - Ler próximo e-mail");
            System.out.println("3 - Sair");
            System.out.print("Escolha: ");
            int choice = in.nextInt();
            in.nextLine(); // Limpar buffer

            switch (choice) {
                case 1:
                    sendMail();
                    break;
                case 2:
                    readMail();
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }

    private void sendMail() {
        System.out.print("De: ");
        String from = in.nextLine();
        System.out.print("Para: ");
        String to = in.nextLine();
        System.out.print("Assunto (opcional): ");
        String subject = in.nextLine();
        System.out.print("Mensagem: ");
        String message = in.nextLine();

        MailItem mail;
        if (subject.equals("")) {
            mail = new MailItem(from, to, message); // Compatível com versão antiga
        } else {
            mail = new MailItem(from, to, subject, message);
        }

        mailbox.addMail(mail);
        System.out.println("E-mail enviado!");
    }

    private void readMail() {
        MailItem mail = mailbox.getNextMail();
        if (mail == null) {
            System.out.println("Nenhum e-mail na caixa!");
        } else {
            mail.print();
        }
    }

    public static void main(String[] args) {
        MailClient client = new MailClient();
        client.run();
    }
}
