/**
 * Caixa de correio que armazena e-mails.
 */
public class MailBox {
    private MailItem[] mailItems;
    private int count;
    private static final int MAX_MAIL = 100;

    public MailBox() {
        mailItems = new MailItem[MAX_MAIL];
        count = 0;
    }

    /**
     * Adiciona um novo e-mail à caixa.
     */
    public void addMail(MailItem item) {
        if (count < MAX_MAIL) {
            mailItems[count] = item;
            count++;
        } else {
            System.out.println("Caixa de correio cheia!");
        }
    }

    /**
     * Retorna o próximo e-mail (FIFO).
     */
    public MailItem getNextMail() {
        if (count == 0) {
            return null;
        }
        MailItem next = mailItems[0];
        // Desloca todos os e-mails para frente
        for (int i = 1; i < count; i++) {
            mailItems[i - 1] = mailItems[i];
        }
        count--;
        return next;
    }

    /**
     * Retorna o número de e-mails na caixa.
     */
    public int getMailCount() {
        return count;
    }
}
