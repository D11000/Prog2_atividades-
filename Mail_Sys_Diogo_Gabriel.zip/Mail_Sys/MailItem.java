/**
 * Representa uma mensagem de e-mail.
 */
public class MailItem {
    private String from;
    private String to;
    private String message;
    private String subject; // Novo campo de assunto

    /**
     * Construtor compatível com e-mails antigos (sem assunto).
     */
    public MailItem(String from, String to, String message) {
        this.from = from;
        this.to = to;
        this.message = message;
        this.subject = ""; // Assunto vazio por padrão
    }

    /**
     * Construtor novo, com assunto.
     */
    public MailItem(String from, String to, String subject, String message) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.message = message;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getMessage() {
        return message;
    }

    public String getSubject() {
        return subject;
    }

    /**
     * Imprime a mensagem de forma legível.
     */
    public void print() {
        System.out.println("De: " + from);
        System.out.println("Para: " + to);
        if (!subject.equals("")) {
            System.out.println("Assunto: " + subject);
        }
        System.out.println("Mensagem: " + message);
        System.out.println("------------------------");
    }
}
