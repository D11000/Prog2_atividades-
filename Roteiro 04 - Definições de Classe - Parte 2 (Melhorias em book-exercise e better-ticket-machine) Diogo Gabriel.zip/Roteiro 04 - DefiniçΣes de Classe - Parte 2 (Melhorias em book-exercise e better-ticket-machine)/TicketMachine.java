/**
 * TicketMachine models a naive ticket machine that issues
 * flat-fare tickets.
 * The price of a ticket is specified via the constructor.
 * It is a naive machine in the sense that it trusts its users
 * to insert enough money before trying to print a ticket.
 * It also assumes that users enter sensible amounts.
 *
 * @author David J. Barnes and Michael Kolling
 * @version 2008.03.30
 */
import java.util.Scanner;
public class TicketMachine
{
    Scanner in= new Scanner(System.in);



    // The price of a ticket from this machine.
    private int price;
    // The amount of money entered by a customer so far.
    private int balance;
    // The total amount of money collected by this machine.
    private int total;
    private int change;
    private int currentPrice;


    /**
     * Create a machine that issues tickets of the given price.
     * Note that the price must be greater than zero, and there
     * are no checks to ensure this.
     */
    public TicketMachine(int ticketCost)
    
    {




        price = 0;
        setPrice(ticketCost);
        balance = 0;
        total = 0;
        while (price<=0){
            System.out.println("Valor invalido digite novamente");
            int replacecost=in.nextInt();
            price=replacecost;

        }
    }


    /**
     * Return the price of a ticket.
     */
    public int getPrice()
    {
        return price;
    }

    public void setPrice(int newPrice){
        if (newPrice>=0){
        price= newPrice;}
        else {
            System.out. println("Valor invalido");
        }



    }

    /**
     * Return the amount of money already inserted for the
     * next ticket.
     */
    public int getBalance()
    {
        return balance;
    }

    /**
     * Receive an amount of money in cents from a customer.
     */
    public void insertMoney(int amount)
    {
        while (amount<=0){
            System.out.println("Valor invalido. Digite novamente:");
            int correctprice= in.nextInt();
            amount = correctprice;
        }

        balance = balance + amount;






    }

    /**
     * Print a ticket.
     * Update the total collected and
     * reduce the balance to zero.
     */
    public void printTicket()
    
    {
        
        if(price == balance ){
        // Simulate the printing of a ticket.
        System.out.println("##################");
        System.out.println("# The BlueJ Line");
        System.out.println("# Ticket");
        System.out.println("# " + price + " cents.");
        System.out.println("##################");
        System.out.println();

        // Update the total collected with the balance.
        total = total + balance;
        // Clear the balance.
        balance = 0;}
        
        else if(balance>price) {
            change=balance-price;
        System.out.println("##################");
        System.out.println("# The BlueJ Line");
        System.out.println("# Ticket");
        System.out.println("# " + price + " cents.");
        System.out.println("##################");
        System.out.println("Change " +change + " cents.");
        System.out.println();

        // Update the total collected with the balance.
        total = total + balance;
        // Clear the balance.
        balance = 0;
           

        }
        else {
            System.out.println("Valor insuficiente");
        }

    }


    public int emptyMachine (){
        int total1 = total;
        total = 0;
        return total1;
        // Esse metodo é um metodo modificador e de acesso




    }
    public void selectTicketPrice() { // 🔸
        System.out.println("Selecione o tipo de bilhete:");
        System.out.println("1. Bilhete comum - " + price + " centavos");
        System.out.println("2. Bilhete semileito - " + (int)(price * 1.5) + " centavos");
        System.out.println("3. Bilhete leito - " + (int)(price * 2) + " centavos");

        int opcao = in.nextInt();
        switch (opcao) {
            case 1:
                currentPrice = price;
                break;
            case 2:
                currentPrice = (int)(price * 1.5);
                break;
            case 3:
                currentPrice = (int)(price * 2);
                break;
            default:
                System.out.println("Opção inválida. Usando preço padrão.");
                currentPrice = price;
        }

        System.out.println("Preço selecionado: " + currentPrice + " centavos");
    }





}
