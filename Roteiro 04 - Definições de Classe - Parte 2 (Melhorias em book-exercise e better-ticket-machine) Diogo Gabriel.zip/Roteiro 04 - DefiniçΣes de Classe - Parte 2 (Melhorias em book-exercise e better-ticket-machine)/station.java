

public class station{
private TicketMachine convencional;
private TicketMachine semi_leito;
private TicketMachine leito;
//private int numMachine;
private int rate ;





    public station(int currentRate, int basePrice) {
        //numMachine=1;
        this.rate = currentRate;
        int preco_convencional =(basePrice);
        int preco_Semi_leito = (int) (basePrice * (1 + rate / 100.0));
        int preco_Leito = (int) (basePrice * (1 + 2 * (rate / 100.0)));
        convencional = new TicketMachine(preco_convencional);
        semi_leito = new TicketMachine(preco_Semi_leito);
        leito = new TicketMachine(preco_Leito);

    }
    public TicketMachine getConvencional() {
        return convencional;
    }

        public TicketMachine getSemileito() {
        return semi_leito;
    }

        public TicketMachine getLeito() {
        return leito;
    }

        public int getRate() {
        return rate;
    }


    }


    
