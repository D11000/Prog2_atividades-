/**
 * Cliente de e-mail de um usuário.
 * Envia e recebe mensagens através de um MailServer.
 */
public class MailClient {
    private MailServer servidor;
    private String usuario;
    private MailBox caixa;

    public MailClient(MailServer servidor, String usuario) {
        this.servidor = servidor;
        this.usuario = usuario;
        this.caixa = new MailBox();
        servidor.registrarUsuario(usuario, caixa);
    }

    /**
     * Envia e-mail sem assunto (compatível com versão anterior).
     */
    public void sendMailItem(String to, String message) {
        sendMailItem(to, "", message);
    }

    /**
     * Envia e-mail com assunto.
     */
    public void sendMailItem(String to, String subject, String message) {
        MailItem item = new MailItem(usuario + "@" + servidor.getDominio(), to, subject, message);
        servidor.enviar(item);
    }

    /**
     * Lê e imprime a próxima mensagem.
     */
    public void getNextMailItem() {
        MailItem item = caixa.obterProximo();
        if (item != null) {
            item.print();
        } else {
            System.out.println("📭 Nenhuma nova mensagem.");
        }
    }

    public void printAllMail() {
        caixa.imprimirTodas();
    }
}
