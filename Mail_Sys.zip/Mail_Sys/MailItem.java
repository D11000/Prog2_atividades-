/**
 * Representa um item de e-mail.
 * Agora com campo de assunto opcional.
 */
public class MailItem {
    private String from;
    private String to;
    private String subject;  // novo campo
    private String message;

    /**
     * Construtor compatível com versões anteriores (sem assunto).
     */
    public MailItem(String from, String to, String message) {
        this(from, to, "", message); // assunto vazio
    }

    /**
     * Construtor completo com assunto.
     */
    public MailItem(String from, String to, String subject, String message) {
        this.from = from;
        this.to = to;
        this.subject = (subject == null) ? "" : subject;
        this.message = message;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public String getSubject() {
        return subject;
    }

    public String getMessage() {
        return message;
    }

    /**
     * Imprime a mensagem formatada.
     */
    public void print() {
        System.out.println("----------------------------------------");
        System.out.println("De: " + from);
        System.out.println("Para: " + to);
        if (!subject.isEmpty()) {
            System.out.println("Assunto: " + subject);
        }
        System.out.println("Mensagem: " + message);
        System.out.println("----------------------------------------");
    }
}
