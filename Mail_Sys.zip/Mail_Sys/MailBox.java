import java.util.LinkedList;
import java.util.Queue;

/**
 * Representa a caixa de entrada de um usuário.
 */
public class MailBox {
    private Queue<MailItem> mensagens;

    public MailBox() {
        mensagens = new LinkedList<>();
    }

    public void adicionar(MailItem item) {
        mensagens.add(item);
    }

    public MailItem obterProximo() {
        return mensagens.poll();
    }

    public boolean temMensagens() {
        return !mensagens.isEmpty();
    }

    public void imprimirTodas() {
        if (mensagens.isEmpty()) {
            System.out.println("📭 Nenhuma mensagem.");
        } else {
            for (MailItem item : mensagens) {
                item.print();
            }
        }
    }
}
