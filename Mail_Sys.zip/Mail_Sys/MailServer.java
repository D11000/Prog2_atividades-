import java.util.HashMap;
import java.util.Map;

/**
 * Servidor de e-mail.
 * Suporta múltiplos servidores com diferentes domínios.
 */
public class MailServer {
    private static Map<String, MailServer> servidoresRegistrados = new HashMap<>();

    private String dominio;
    private Map<String, MailBox> caixas;

    public MailServer(String dominio) {
        this.dominio = dominio;
        caixas = new HashMap<>();
        servidoresRegistrados.put(dominio, this);
    }

    public String getDominio() {
        return dominio;
    }

    public void registrarUsuario(String nome, MailBox caixa) {
        caixas.put(nome, caixa);
    }

    public static MailServer getServidor(String dominio) {
        return servidoresRegistrados.get(dominio);
    }

    /**
     * Envia mensagem, podendo ser para outro servidor.
     */
    public void enviar(MailItem item) {
        String destino = item.getTo();

        String[] partes = destino.split("@");
        String nomeDestino = partes[0];
        String dominioDestino = partes.length > 1 ? partes[1] : this.dominio;

        MailServer servidorDestino = servidoresRegistrados.get(dominioDestino);

        if (servidorDestino != null) {
            servidorDestino.entregarMensagem(nomeDestino, item);
        } else {
            System.out.println("❌ Servidor destino '" + dominioDestino + "' não encontrado.");
        }
    }

    private void entregarMensagem(String nomeUsuario, MailItem item) {
        MailBox caixa = caixas.get(nomeUsuario);
        if (caixa != null) {
            caixa.adicionar(item);
        } else {
            System.out.println("❌ Usuário '" + nomeUsuario + "' não encontrado no servidor " + dominio);
        }
    }
}
